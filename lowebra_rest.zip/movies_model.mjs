import mongoose from 'mongoose';
import 'dotenv/config';

mongoose.connect(
    process.env.MONGODB_CONNECT_STRING,
    { useNewUrlParser: true }
);


// Connect to to the database
const db = mongoose.connection;
// The open event is called when the database connection successfully opens
db.once("open", () => {
    console.log("Successfully connected to MongoDB using Mongoose!");
});

/**
 * Define the schema
 */
const movieSchema = mongoose.Schema({
    name: { type: String, required: true },
    reps: { type: Number, required: true },
    weight: { type: Number, required: true},
    unit: { type: String, required: true },
    date: { type: String, required: true }
});

/**
 * Compile the model from the schema. This must be done after defining the schema.
 */
const Movie = mongoose.model("Movie", movieSchema);


const createMovie = async (name, reps, weight, unit, date) => {
    const movie = new Movie({ name: name, reps: reps, weight: weight, unit: unit, date: date});
    return movie.save();
}

const findMovies = async (filter, projection, limit) => {
    const query = Movie.find(filter)
        .select(projection)
        .limit(limit);
    return query.exec();
}

const findMovieById = async(_id) => {
    const query = Movie.findById(_id);
    return query.exec();
}

const replaceMovie = async (_id, name, reps, weight, unit, date) => {
    const result = await Movie.replaceOne({_id:_id}, {name: name, reps: reps, weight: weight, unit: unit, date: date});
    return result.modifiedCount;
}

const deleteById = async (_id) => {
    const result = await Movie.deleteOne({ _id: _id });
    return result.deletedCount;
}

export { createMovie }
export { findMovies }
export { findMovieById }
export { replaceMovie }
export { deleteById }